#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i;

    scanf("%5.2d", &i);

    return 0;
}
