#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, j;
    float x, y;

    scanf("%d%d%f%f", &i, &j, &x, &y); //1 -20 .3 -4.0e3

    return 0;
}
