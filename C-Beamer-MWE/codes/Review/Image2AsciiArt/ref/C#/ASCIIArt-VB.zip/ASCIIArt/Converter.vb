Imports System
imports System.Drawing
imports System.Drawing.Imaging
imports System.IO
imports System.Text
imports System.Web
Namespace Converter


	Public Class AsciiArt
		Private mRows As Integer
		Private mCols As Integer

		Public Event Processed(ByVal row As Integer, ByVal col As Integer, ByVal maxRows As Integer, ByVal maxCols As Integer)
		Public Function ConvertImage(ByVal stream As Stream) As String

			Dim _asciiart As StringBuilder = New StringBuilder

			Dim _img As Image = Image.FromStream(stream)

			Dim _image As Bitmap = New Bitmap(_img, New Size(_img.Width, _img.Height))
			_img.Dispose()


			Dim bounds As Rectangle = New Rectangle(0, 0, _image.Width, _image.Height)

			Dim _matrix As ColorMatrix = New ColorMatrix


			_matrix(0, 0) = 1 / 3.0F
			_matrix(0, 1) = 1 / 3.0F
			_matrix(0, 2) = 1 / 3.0F
			_matrix(1, 0) = 1 / 3.0F
			_matrix(1, 1) = 1 / 3.0F
			_matrix(1, 2) = 1 / 3.0F
			_matrix(2, 0) = 1 / 3.0F
			_matrix(2, 1) = 1 / 3.0F
			_matrix(2, 2) = 1 / 3.0F

			Dim _attributes As ImageAttributes = New ImageAttributes
			_attributes.SetColorMatrix(_matrix)


			Dim gphGrey As Graphics = Graphics.FromImage(_image)
			gphGrey.DrawImage(_image, bounds, 0, 0, _image.Width, _image.Height, GraphicsUnit.Pixel, _attributes)

			gphGrey.Dispose()

			mRows = CType(_image.Height / 10, Integer)
			mCols = CType(_image.Width / 5, Integer)
			For h As Integer = 0 To mRows

				Dim _startY As Integer = (h * 10)

				For w As Integer = 0 To mCols

					Dim _startX As Integer = (w * 5)

					RaiseEvent Processed(h, w, mRows, mCols)

					Dim _allBrightness As Integer = 0

					For y As Integer = 0 To 10
						For x As Integer = 0 To 10
							Dim _cY As Integer = y + _startY
							Dim _cX As Integer = x + _startX
							Try
								Dim _c As Color = _image.GetPixel(_cX, _cY)

								Dim _b As Integer = CType((_c.GetBrightness() * 10), Integer)
								_allBrightness = (_allBrightness + _b)
							Catch
								_allBrightness = (_allBrightness + 10)
							End Try
						Next
					Next

					Dim _sb As Integer = CType((_allBrightness / 10), Integer)
					If (_sb < 25) Then
						_asciiart.Append("#")
					ElseIf (_sb < 30) Then
						_asciiart.Append("@")
					ElseIf (_sb < 40) Then
						_asciiart.Append("�")
					ElseIf (_sb < 45) Then
						_asciiart.Append("$")
					ElseIf (_sb < 50) Then
						_asciiart.Append("&")
					ElseIf (_sb < 55) Then
						_asciiart.Append("�")
					ElseIf (_sb < 60) Then
						_asciiart.Append("~")
					ElseIf (_sb < 60) Then
						_asciiart.Append("�")
					ElseIf (_sb < 70) Then
						_asciiart.Append("�")
					ElseIf (_sb < 80) Then
						_asciiart.Append("�")
					ElseIf (_sb < 90) Then
						_asciiart.Append("�")
					Else
						_asciiart.Append(" ")
					End If
				Next
				_asciiart.Append(Environment.NewLine)

			Next

			_image.Dispose()


			Return _asciiart.ToString()

		End Function
	End Class
End Namespace

