Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
	Friend WithEvents txtStatus As System.Windows.Forms.TextBox
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Me.txtStatus = New System.Windows.Forms.TextBox
		Me.SuspendLayout()
		'
		'txtStatus
		'
		Me.txtStatus.Location = New System.Drawing.Point(20, 3)
		Me.txtStatus.Name = "txtStatus"
		Me.txtStatus.Size = New System.Drawing.Size(544, 20)
		Me.txtStatus.TabIndex = 0
		Me.txtStatus.Text = "TextBox1"
		'
		'Form1
		'
		Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
		Me.ClientSize = New System.Drawing.Size(571, 273)
		Me.Controls.Add(Me.txtStatus)
		Me.Name = "Form1"
		Me.Text = "Form1"
		Me.ResumeLayout(False)

	End Sub

#End Region

	Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
		Me.Show()
		Me.Refresh()

		Dim tt As Converter.AsciiArt
		tt = New Converter.AsciiArt
		AddHandler tt.Processed, AddressOf tt2_Processed

		Dim ir As Image

		Dim bkgndPath As String
		Dim img As System.Drawing.Image

		bkgndPath = "\\cglnt003\webdevelopment\23v4\rootpublic\images\content.jpg"
		bkgndPath = "\\cglnt003\webdevelopment\23v4\rootpublic\images\content_1.jpg"
		bkgndPath = "C:\normal_wallchrome1final.jpg"

		If System.IO.File.Exists(bkgndPath) Then
			Dim imgStream As System.IO.StreamReader
			imgStream = New System.IO.StreamReader(bkgndPath)
			img = System.Drawing.Image.FromStream(imgStream.BaseStream)
			Console.WriteLine(tt.ConvertImage(imgStream.BaseStream))
			imgStream.Close()
		End If

	End Sub


	Private Sub tt2_Processed(ByVal row As Integer, ByVal col As Integer, ByVal maxRows As Integer, ByVal maxCols As Integer)
		txtStatus.Text = String.Concat("{0} - {1} = {2} - {3}", row, col, maxRows, maxCols)
		txtStatus.Refresh()

	End Sub
End Class
